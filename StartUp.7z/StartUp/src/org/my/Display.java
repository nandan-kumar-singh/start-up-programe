package org.my;

import java.awt.AWTException;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Robot;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JWindow;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileSystemView;

import org.eclipse.wb.swing.FocusTraversalOnArray;

@SuppressWarnings("serial")
public class Display extends JWindow {

	private Toolkit toolkit;
	private Dimension dim;
	private static Display frame;
	private Runtime rt = Runtime.getRuntime();
	private Desktop desktop = Desktop.getDesktop();
	private Robot rob;
	private static FileSystemView fileSystemView = FileSystemView
			.getFileSystemView();;
	// private final Action action = new SwingAction();
	private JButton[] btnDrive = new JButton[10];
	private JPanel panelDrive;
	/* private File []file=File.listRoots();; */
	private JComboBox<String> comboBoxPower;
	private JButton btnOK;
	public static String OS_name;
	private JButton btnHide, btnShow;
	private Thread thread;
	private Process process = null;
	private BufferedImage image;

	public static void main(String[] args) {
		// UIManager.put("nimbusBase",new Color(145,167,233) );
		// UIManager.put("nimbusBlueGrey", new Color(245,67,133));
		// UIManager.put("control", Color.red);
		for (UIManager.LookAndFeelInfo info : UIManager
				.getInstalledLookAndFeels()) {
			// System.out.println(info.getName());

			if ("Nimbus".equals(info.getName())) {
				try {
					UIManager.setLookAndFeel(info.getClassName());
				} catch (Exception exc) {
					Toolkit.getDefaultToolkit().beep();
				}
			}
		}
		OS_name = "Powered By Nandan for " + System.getProperty("os.name");
		// System.out.println(System.getProperties());
		frame = new Display();
		frame.setVisible(true);
		/*
		 * EventQueue.invokeLater(new Runnable() { public void run() { try {
		 * 
		 * 
		 * } catch (Exception e) { e.printStackTrace(); } } });
		 */

	}

	/**
	 * Create the frame.
	 */
	public Display() {
		setName("StartUp");
		setOpacity(0.92f);
		setAlwaysOnTop(true);
		setType(Type.POPUP);
		getContentPane().setCursor(
				Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		// new SendMailMe().setVisible(true);
		try {
			rob = new Robot();
		} catch (AWTException e2) {

			e2.printStackTrace();
		}
		setAlwaysOnTop(true);
		toolkit = Toolkit.getDefaultToolkit();
		dim = toolkit.getScreenSize();
		this.setSize(dim.width, dim.height / 4);
		this.setLocationRelativeTo(null);
		getContentPane().setBackground(getPixelColor());
		getContentPane().setLayout(null);

		btnShow = new JButton("\u0000");
		btnShow.setForeground(SystemColor.inactiveCaption);
		btnShow.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnShow.setHorizontalTextPosition(SwingConstants.RIGHT);
		btnShow.setBackground(SystemColor.controlShadow);

		// btnNewButton.setAction(action);
		btnShow.setMnemonic(KeyEvent.VK_TAB);

		btnShow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// panelDrive.removeAll();

				// setPixelColor();

				// driveInfo();
				for (int i = 0; i < dim.width; i += 600) {
					frame.setSize(i, dim.height / 4);
					// frame.setLocation(i,dim.height);
					try {
						Thread.sleep(1);
					} catch (InterruptedException e1) {

					}
					validate();
				}
				frame.setSize(dim.width, dim.height / 4);
				frame.setLocationRelativeTo(null);
				setAlwaysOnTop(true);
				repaint();
				// validate();

			}
		});
		btnShow.setBounds(-6, -6, 27, 714);
		getContentPane().add(btnShow);

		JPanel panel = new JPanel();
		panel.setFont(new Font("Rod", Font.PLAIN, 12));
		panel.setOpaque(false);
		panel.setBounds(1342, -21, 45, 246);
		getContentPane().add(panel);
		panel.setLayout(new GridLayout(0, 1, 0, 0));

		btnHide = new JButton("");
		btnHide.setIcon(new ImageIcon("/1_navigation_next_item.png"));
		btnHide.setBackground(SystemColor.controlShadow);
		btnHide.setFont(new Font("SansSerif", Font.PLAIN, 10));
		btnHide.setMnemonic(KeyEvent.VK_AT);
		panel.add(btnHide);
		btnHide.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				/**/
				frame.setLocation(dim.width - 2, dim.height / 7);
				frame.setSize(dim.width / 3, dim.height);
				setPixelColor();
				try {
					this.finalize();
				} catch (Throwable e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				// frame.setAlwaysOnTop(true);
				// //timer.stop();
				/*
				 * if(frame.isAlwaysOnTopSupported()) {
				 * frame.setAlwaysOnTop(true); }
				 */
				btnOK.setEnabled(false);
				rt.gc();
				// System.gc();

			}
		});

		JPanel panel_2 = new JPanel() ;
		panel_2.setBorder(new EmptyBorder(1, 2, 0, 0));
		panel_2.setOpaque(false);
		panel_2.setBounds(21, 6, 690, 180);
		getContentPane().add(panel_2);
		panel_2.setLayout(new GridLayout(0, 4, 0, 0));

		JButton btnComputer = new JButton("Computer");
		btnComputer.setMnemonic('A');
		btnComputer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { // btnHide.doClick();
				try {
					rt.exec("explorer.exe \"\"");
					rt.runFinalization();
				} catch (IOException e1) {

					e1.printStackTrace();
				}
				btnHide.doClick();

			}
		});
		panel_2.add(btnComputer);

		JButton btnStart = new JButton("Start");
		btnStart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnHide.doClick();
				rob.keyPress(KeyEvent.VK_WINDOWS);
				rob.keyRelease(KeyEvent.VK_WINDOWS);
			}
		});
		panel_2.add(btnStart);

		JButton btnPaint = new JButton("Paint");
		btnPaint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnHide.doClick();
				try {
					rt.exec("mspaint");
				} catch (IOException e1) {

					e1.printStackTrace();
				}
			}
		});
		panel_2.add(btnPaint);

		JButton btnRun = new JButton("Run");
		btnRun.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnHide.doClick();
				rob.keyPress(KeyEvent.VK_WINDOWS);
				rob.keyPress(KeyEvent.VK_R);

				rob.keyRelease(KeyEvent.VK_WINDOWS);
				rob.keyRelease(KeyEvent.VK_R);
			}
		});
		panel_2.add(btnRun);

		JButton btnControlPanel = new JButton("Control Panel");
		btnControlPanel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					rt.exec("control panel");
				} catch (IOException e1) {

					e1.printStackTrace();
				}
				btnHide.doClick();
				// desktop.open("");

			}
		});
		panel_2.add(btnControlPanel);

		JButton btnCommand = new JButton("Command");
		btnCommand.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				/*
				 * rob.keyPress(KeyEvent.VK_WINDOWS);
				 * rob.keyPress(KeyEvent.VK_R);
				 * 
				 * rob.keyRelease(KeyEvent.VK_WINDOWS);
				 * rob.keyRelease(KeyEvent.VK_R);
				 */

				try {
					Desktop.getDesktop().open(
							new File(System.getenv("systemroot")
									+ "/system32/cmd.exe"));
				} catch (IOException ex) {

					ex.printStackTrace();
				}
				btnHide.doClick();
			}
		});
		panel_2.add(btnCommand);

		JButton btnNotepad = new JButton("Notepad");
		btnNotepad.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnHide.doClick();
				try {
					rt.exec("notepad");
				} catch (IOException e1) {

					e1.printStackTrace();
				}
			}
		});
		panel_2.add(btnNotepad);

		JButton btnNetworkSettings = new JButton("Network");
		btnNetworkSettings.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnHide.doClick();
				try {
					rt.exec(new String[] { "cmd", "/c", "ncpa.cpl", });

				} catch (IOException e1) {
					try {
						rt.exec("Control netconnections");
					} catch (IOException e2) {

					}

				}
			}
		});
		panel_2.add(btnNetworkSettings);

		JButton btnSystemInfo = new JButton("System Info.");
		btnSystemInfo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnHide.doClick();
				try {
					rt.exec("dxdiag");
				} catch (IOException e1) {

					e1.printStackTrace();
				}

			}
		});
		panel_2.add(btnSystemInfo);

		JButton btnPersonalization = new JButton("Personalize");
		btnPersonalization.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnHide.doClick();
				// Control desktop
				try {
					rt.exec("control desktop");
				} catch (IOException e1) {

					e1.printStackTrace();
				}
			}
		});

		panel_2.add(btnPersonalization);

		JButton btnAdminTools = new JButton("Admin Tools");
		btnAdminTools.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnHide.doClick();
				try {
					rt.exec("control admintools");
					rt.runFinalization();

				} catch (IOException e1) {

					e1.printStackTrace();
				}
			}
		});
		panel_2.add(btnAdminTools);

		JButton btnfacebook = new JButton("Facebook");
		btnfacebook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnHide.doClick();
				try {
					desktop.browse(new URI("www.facebook.com"));
				} catch (IOException e1) {

					e1.printStackTrace();
				} catch (URISyntaxException e1) {

					e1.printStackTrace();
				}
			}
		});
		panel_2.add(btnfacebook);

		panelDrive = new JPanel();
		panelDrive.setOpaque(false);
		panelDrive.setBounds(723, 6, 607, 139);
		getContentPane().add(panelDrive);
		panelDrive.setLayout(new GridLayout(0, 4, 0, 0));

		btnOK = new JButton("Ok");
		btnOK.setEnabled(false);
		btnOK.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int option = comboBoxPower.getSelectedIndex();
				switch (option) {
				case 0: {
					try {
						rt.exec("shutdown /p");
					} catch (IOException e1) {
					}
					break;
				}
				case 1: {
					try {
						rt.exec("shutdown /r");
					} catch (IOException e1) {
					}
					break;
				}
				case 2: {
					try {
						rt.exec("shutdown /h");
					} catch (IOException e1) {
					}
					break;
				}
				case 3: {
					try {
						rt.exec("shutdown /l");
					} catch (IOException e1) {
					}
					break;
				}
				case 4: {
					System.exit(0);
					break;
				}

				}
			}
		});
		comboBoxPower = new JComboBox<String>(){

			/* (non-Javadoc)
			 * @see javax.swing.JComboBox#isPopupVisible()
			 */
			@Override
			public boolean isPopupVisible() {
				// TODO Auto-generated method stub
				return super.isPopupVisible();
			}
			
		};
		comboBoxPower.getGraphicsConfiguration().
		comboBoxPower.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				btnOK.setEnabled(true);
			}
		});
		comboBoxPower.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { // btnHide.doClick();
				// btnOK.setEnabled(true);
			}
		});

		comboBoxPower.setBounds(723, 148, 199, 38);
		getContentPane().add(comboBoxPower);
		comboBoxPower.setModel(new DefaultComboBoxModel<String>(
				new String[] { "Shutdown", "Restart", "Hibernate", "Log off",
						"Exit Programme" }));
		comboBoxPower.setSelectedIndex(2);

		btnOK.setBounds(944, 148, 132, 38);
		getContentPane().add(btnOK);

		JLabel labelOsName = new JLabel(OS_name);
		labelOsName.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				if (e.getClickCount() == 5) {
					btnHide.doClick();
					toolkit.beep();
					JOptionPane
							.showMessageDialog(
									null,
									"For further detail mail us at: nandansingh024@gmail.com",
									"Mail Us", JOptionPane.INFORMATION_MESSAGE,
									new ImageIcon("images/move.gif"));
					btnShow.doClick();
				}

			}
		});
		labelOsName.setHorizontalAlignment(SwingConstants.CENTER);

		labelOsName.setForeground(Color.BLACK);
		labelOsName.setFont(new Font("Dialog", Font.PLAIN, 14));
		labelOsName.setBounds(1076, 148, 254, 38);
		getContentPane().add(labelOsName);
		setFocusTraversalPolicy(new FocusTraversalOnArray(new Component[] {
				getContentPane(), btnShow, panel, btnHide, panel_2,
				btnComputer, btnStart, btnPaint, btnRun, btnControlPanel,
				btnCommand, btnNotepad, btnNetworkSettings, btnSystemInfo,
				btnPersonalization, btnAdminTools, btnfacebook, panelDrive,
				comboBoxPower, btnOK, labelOsName }));
		driveInfo();

		thread = new Thread() {
			@Override
			public void run() {
				super.run();
				while (true) {
					try {

						// System.out.println(demo++);
						Thread.sleep(10000);
						driveInfo();

					} catch (Exception e) {
					}
				}

			}
		};
		thread.start();

	}

	// int demo=0;
	public void setPixelColor() {
		this.getContentPane().setBackground(getPixelColor());

	}

	public Color getPixelColor() {
		Robot rob = null;
		try {
			rob = new Robot();
		} catch (AWTException e) {

			e.printStackTrace();
		}
		Color col = rob.getPixelColor(3, dim.height - 3);
		return col;
	}

	public void driveInfo() {
		panelDrive.removeAll();
		//

		byte i = 0;

		File[] file = File.listRoots();
		for (File f : file) {
			if (f.canWrite() || f.canRead()) {
				i++;
				final String drive = f.getAbsolutePath();

				btnDrive[i] = new JButton(
						fileSystemView.getSystemDisplayName(f));
				btnDrive[i].setIcon(fileSystemView.getSystemIcon(f));
				btnDrive[i].addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
						btnHide.doClick();
						try {
							if (process != null)
								process.destroy();
							// rt.exec("explorer.exe");
							process = rt.exec("explorer.exe " + drive);
						} catch (IOException e1) {
						}

					}
				});

				// btnDrive[i].setName(fileSystemView.getSystemDisplayName(f));
				panelDrive.add(btnDrive[i]);

			}

		}
		repaint();
		panelDrive.validate();

	}

}
