package org.my;

import java.awt.EventQueue;

import javax.swing.JWindow;
import javax.swing.JRadioButton;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.awt.Color;
import java.awt.SystemColor;

public class SendMailMe extends JWindow {

	/**
	 * Launch the application.
	 */
	static SendMailMe frame1 ;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					 frame1 = new SendMailMe();
					frame1.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SendMailMe() {
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(null);
		getContentPane().setBackground(SystemColor.activeCaption);
		
		JRadioButton rdbtnExit = new JRadioButton("Exit");
		rdbtnExit.setBackground(Color.RED);
		rdbtnExit.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				frame1.setVisible(false);
			}
		});
		rdbtnExit.setBounds(389, 7, 55, 23);
		getContentPane().add(rdbtnExit);
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}
}
