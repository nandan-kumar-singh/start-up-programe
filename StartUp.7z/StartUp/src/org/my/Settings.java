/*package org.my;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Window;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.SwingConstants;

public class Settings extends JFrame {

	private JPanel contentPane;

	*//**
	 * Launch the application.
	 *//*
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Settings frame = new Settings();
					frame.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	*//**
	 * Create the frame.
	 *//*
	public Settings() {
		setTitle("Settings");
		setType(Window.Type.UTILITY);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLocation(0, 0);
		setSize(500, 200);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnLocation = new JButton("Location");
		btnLocation.setBounds(10, 11, 104, 32);
		contentPane.add(btnLocation);
		
		JLabel label = new JLabel("");
		label.setBounds(124, 11, 355, 32);
		contentPane.add(label);
		
		JButton btnHomeFolder = new JButton("Home Folder");
		btnHomeFolder.setBounds(10, 54, 104, 32);
		contentPane.add(btnHomeFolder);
		
		JLabel lblDesktop = new JLabel("Desktop");
		lblDesktop.setHorizontalAlignment(SwingConstants.CENTER);
		lblDesktop.setBounds(124, 54, 355, 32);
		contentPane.add(lblDesktop);
		
		JButton btnColor = new JButton("Color");
		btnColor.setBounds(10, 97, 104, 32);
		contentPane.add(btnColor);
		
		JLabel lblSystemTileColor = new JLabel("System tile color");
		lblSystemTileColor.setHorizontalAlignment(SwingConstants.CENTER);
		lblSystemTileColor.setBounds(124, 97, 356, 32);
		contentPane.add(lblSystemTileColor);
	}
}
*/